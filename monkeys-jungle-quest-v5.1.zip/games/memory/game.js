
const animals = ['monkey','lion','elephant','zebra','parrot','toucan','snake','frog'];
let deck = [];
let first=null, second=null, lock=false, moves=0, pairs=0;

const grid = document.getElementById('grid');
const movesEl = document.getElementById('moves');
const pairsEl = document.getElementById('pairs');
const resetBtn = document.getElementById('reset');

function shuffle(arr){ for(let i=arr.length-1;i>0;i--){ const j = Math.floor(Math.random()*(i+1)); [arr[i],arr[j]]=[arr[j],arr[i]]; } return arr; }

function createCard(name){
  const el = document.createElement('div');
  el.className = 'card';
  el.dataset.name = name;
  const img = document.createElement('img');
  img.src = `../../assets/animals/${name}.svg`;
  img.alt = name;
  el.appendChild(img);
  el.addEventListener('click', () => {
    if(lock || el.classList.contains('matched') || el===first) return;
    el.classList.add('revealed');
    if(!first){ first = el; return; }
    second = el; lock = true;
    moves++; movesEl.textContent = moves;
    if(first.dataset.name === second.dataset.name){
      first.classList.add('matched'); second.classList.add('matched');
      pairs++; pairsEl.textContent = pairs;
      resetSelection();
      if(pairs===8){ setTimeout(()=> alert('Yay! You matched them all!'), 300); }
    } else {
      setTimeout(()=>{
        first.classList.remove('revealed');
        second.classList.remove('revealed');
        resetSelection();
      }, 600);
    }
  });
  return el;
}

function resetSelection(){ first=null; second=null; lock=false; }

function init(){
  deck = shuffle([...animals, ...animals]);
  grid.innerHTML='';
  moves=0; pairs=0; movesEl.textContent='0'; pairsEl.textContent='0';
  deck.forEach(name => grid.appendChild(createCard(name)));
}
resetBtn.addEventListener('click', init);
init();
